var modalID;
var isModal = false;
$(function() {

    $('.custom-modal-toggle').click(function() {
        modalID = $(this).data('href');
        $(modalID).addClass('showOn');
        isModal = true;
    });

    $('.custom-modal').click(function(e) {
        $(this).removeClass('showOn');
    });
    $('.modal-dismiss').click(function() {
        $(modalID).removeClass('showOn');
        isModal = false;
    });

    $('.custom-modal-content').click(function(e) {
        if (isModal) {
            e.stopPropagation();
        }
    });
    // $('.vesta-dropdown').click(function() {
    //     if (!$(this).hasClass('disabled')) {
    //         $(this).toggleClass('showOn');
    //     }
    // });

    // $('.custom-item').click(function() {
    //     var customLabel = $(this).data('item');
    //     console.log($(this).parent())
    //     $(this).parent().prev('.vesta-select').html(customLabel);
    // });

});


function showModal(modalID) {
    isModal = true;
    $(modalID).addClass('showOn');
}