$(function() {

    $('input:radio[name="stepOneRadio"]').eq(0).click()
    $('.skip_step').click(function() {
        $("#selection_bx,#buy_orders_first,#buy_orders_by_volume,#buy_orders_by_questions,#buy_orders").hide();
        $("#thank_page").show();
    });

    $(".second_stage_order li").click(function(){
        $(this).addClass('active').siblings().removeClass('active');
    });
    $(".second_stage_volume li").click(function(){
        $(this).addClass('active').siblings().removeClass('active');
    });

    $(".third_stage_order li").click(function(){
        $(this).addClass('active').siblings().removeClass('active');
    });

    $(".first_step_click").click(function(){
        var val = $('input:radio[name="stepOneRadio"]:checked').val();
        $("#buy_orders_by_volume").hide();
        $("#selection_bx").hide();
        
        // if(val == '1'){
        //     $("#buy_orders_by_volume").hide();
        //     handelNextMove('selection_bx','buy_orders_first')

        // }else{
        //     $("#selection_bx").hide();
        //     $("#buy_orders_first").hide();
        //     $("#buy_orders_by_volume").show();
        // }
    });


});
