var dataSet = [
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Shanu", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "4", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "3", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "2", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "1", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
    ["Christopher Blue", "0", "2021-04-06", "Payment Protect", "Shopify", "Christopherblue@abc.com", "(+44) 789 6547 675", "<img src='img/table-open-arrow.svg' />"],
];
var dataSet2 = [
    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Edward Scissorhands", "#0123456789", "<div><ul><li>Member</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r4.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li></ul></div>", "<div class='email_bx'>scissorhandsedward@westopfraud.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rapunzel Grimm", "#0123456789", "<div><ul><li>Super</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li><li><span>+8</span></li></ul></div>", "<div class='email_bx'>longhairrapunzelrescuedbyprince@quarantinebymomatcastl</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Blue", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>Christopherblue@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],


    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Edward Scissorhands", "#0123456789", "<div><ul><li>Member</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r4.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li></ul></div>", "<div class='email_bx'>scissorhandsedward@westopfraud.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rapunzel Grimm", "#0123456789", "<div><ul><li>Super</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li><li><span>+8</span></li></ul></div>", "<div class='email_bx'>longhairrapunzelrescuedbyprince@quarantinebymomatcastl</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Blue", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>Christopherblue@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Edward Scissorhands", "#0123456789", "<div><ul><li>Member</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r4.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li></ul></div>", "<div class='email_bx'>scissorhandsedward@westopfraud.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Vivianne Christopher", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>rachelviv@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rapunzel Grimm", "#0123456789", "<div><ul><li>Super</li><li><img src='img/roles/r1.png' /></li> <li><img src='img/roles/r2.png' /></li> <li><img src='img/roles/r3.png' /></li><li><img src='img/roles/r5.png' /></li><li><img src='img/roles/r6.png' /></li><li><img src='img/roles/r10.png' /></li><li><img src='img/roles/r7.png' /></li><li><span>+8</span></li></ul></div>", "<div class='email_bx'>longhairrapunzelrescuedbyprince@quarantinebymomatcastl</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],

    ["Rachel Blue", "#0123456789", "<div><ul><li>Admin</li> <li><img src='img/roles/r2.png' /></li><li><img src='img/roles/r12.png' /></li> <li><img src='img/roles/r3.png' /></li></ul></div>", "<div class='email_bx'>Christopherblue@abc.com</div>", "<div class='contact'>(+44) 789 6547 675 675</div>", "<div><ul><li><button class='dltUser'><span><img src='img/delete-user.png ' /></span></button></li><li><a href='edit-user.html'><span><img src='img/edit-user.png' /></span></a></li> </ul></div>"],



];

var dataSet3 = [
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],
    ["Chase Paymentech", "Christopher Shillingford", "30.12.20", "<div class='accordion_tbl'><a><span></span></a></div>"],

];
$(document).ready(function() {
    $('#vestaTable').DataTable({
        "paging": true,
        data: dataSet,
        "pageLength": 10,
        "language": {
            "paginate": {
                "previous": "Prev",
                "next": "Next"
            },
            "zeroRecords": "Oops! No matching records found.",
            "infoEmpty": "No records available"
        },
        columns: [
            { title: "Merchant Name" },
            { title: "Stage" },
            { title: "Created on" },
            { title: "Product" },
            { title: "From" },
            { title: "Email ID" },
            { title: "Phone" },
            { title: "" }
        ],
        "columnDefs": [{
                "targets": 7,
                "orderable": false
            },
            {
                "targets": 1,
                "createdCell": function(td, cellData, rowData, row, col) {
                    $(td).addClass('PaymentInfo' + cellData);
                    $(td).html('Payment Info')
                }
            }

        ],
    });
    setPagination();
    $('#userTable').DataTable({
        "paging": true,
        data: dataSet2,
        "pageLength": 15,
        "language": {
            "paginate": {
                "previous": "Prev",
                "next": "Next"
            },
            "zeroRecords": "Oops! No matching records found.",
            "infoEmpty": "No records available"
        },
        columns: [
            { title: "User Name" },
            { title: "User ID" },
            { title: "Role" },
            { title: "Email ID" },
            { title: "Phone" },
            { title: "" }
        ],
        "columnDefs": [{
                "targets": 3,
                "createdCell": function(td, cellData, rowData, row, col) {
                    $(td).addClass('email')
                }
            },

            {
                "targets": 4,
                "orderable": false
            },
            {
                "targets": 5,
                "orderable": false
            },
            {
                "targets": 2,
                "createdCell": function(td, cellData, rowData, row, col) {
                    $(td).addClass('role')
                }
            },
            {
                "targets": 5,
                "createdCell": function(td, cellData, rowData, row, col) {
                    $(td).addClass('actions')
                }
            }
        ],
    });
    setPagination();

    function format(d) {
        return '<div class="tabs_inner"> <div class="data_tabs"><div class="header"><div class="profile-tab-container"><ul><li class="link " data-tab="Ppauth">AUTH</li><li class="link"  data-tab="Ppauth">AVS</li><li class="link"  data-tab="Ppauth">CVV</li><li class="link active" data-tab="Ppcb">CB</li></ul></div><a href="#" class="download_data"><img src="img/download.png"></a></div><div class="main_bx profile-tabs" id="inn-Ppauth"><div class="data_head"><ul><li>Processor Code</li><li>Processor Description</li><li>Vesta Code</li><li>Vesta Description</li></ul></div><div class="main_content"><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li></ul></div></div><div class="main_bx profile-tabs table_tabs showOn" id="inn-Ppcb"><div class="data_head"><ul><li>Processor Code</li><li>Processor Description</li><li>Vesta Code</li><li>Vesta Description</li><li>Fraud Indicator</li></ul></div><div class="main_content"><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul><ul><li><span class="code">A0</span></li><li>Transaction Approved/Declined.</li><li><span class="code">01</span></li><li>Transaction Approved/Declined.</li><li>01</li></ul></div></div></div></div></div>';
    }

    var table = $('#paymentTable').DataTable({
        "paging": true,
        data: dataSet3,
        "pageLength": 15,
        "language": {
            "paginate": {
                "previous": "Prev",
                "next": "Next"
            },
            "zeroRecords": "Oops! No matching records found.",
            "infoEmpty": "No records available"
        },
        columns: [
            { title: "Payment Processor Name" },
            { title: "Created by" },
            { title: "Created On" },
            {
                "className": 'details-control',
                "orderable": false,
                "data": null,
                "defaultContent": '<span></span>'
            },
        ],
        "columnDefs": [{
                "targets": 3,
                "orderable": false
            },
            {
                "targets": 3,
                "createdCell": function(td, cellData, rowData, row, col) {
                    $(td).addClass('inside_acc')
                }
            },
        ],

    });

    // Add event listener for opening and closing details
    $('#paymentTable tbody').on('click', 'td.details-control', function() {
        var tr = $(this).closest('tr');
        var row = table.row(tr);

        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            // Open this row
            row.child(format(row.data())).show();
            tr.addClass('shown');
        }
    });

    setPagination();
    
});




$(window).resize(function() {
    setPagination();
});

function setPagination() {
    var tableContainerWidth = $('.main-table-container').width();
    var paginationContainerWidth = $('.dataTables_paginate').width();
    $('.dataTables_paginate').css('left', (tableContainerWidth - paginationContainerWidth) + 80);
}

$(function() {
   
    $("#searchInput").on("input", function(e) {
        e.preventDefault();
        $('#vestaTable').DataTable().search($(this).val()).draw();
        if (($(this).val()).length > 0) {
            $('.table-search-result').html('Showing all results for"' + $(this).val() + '"');
            $('.search-clear').css('display', 'block');
            //Showing all results for “ch”
        } else {
            $('.table-search-result').html('');
            $('.search-clear').css('display', 'none');
        }
    });
    $("#searchUsers").on("input", function(e) {
        e.preventDefault();
        $('#userTable').DataTable().search($(this).val()).draw();
        if (($(this).val()).length > 0) {
            $('.table-search-result').html('Showing all results for"' + $(this).val() + '"');
            $('.search-clear').css('display', 'block');
            //Showing all results for “ch”
        } else {
            $('.table-search-result').html('');
            $('.search-clear').css('display', 'none');
        }
    });

    $('#searchData').on("input", function(e){
        if ($(this).val()){
            $('.search-clear').css('display', 'block');
        }
    });
    

    // $('.sort_def').click(function() {       
    //     $('.control-typo').addClass('no');
    // });
    $("#searchPayment").on("input", function(e) {
        e.preventDefault();
        $('#paymentTable').DataTable().search($(this).val()).draw();
        if (($(this).val()).length > 0) {
            $('.table-search-result').html('Showing all results for"' + $(this).val() + '"');
            $('.search-clear').css('display', 'block');
            //Showing all results for “ch”
        } else {
            $('.table-search-result').html('');
            $('.search-clear').css('display', 'none');
        }
    });
    $("#searchInputM").on("input", function(e) {
        e.preventDefault();
        if (($(this).val()).length > 0) {
            $('.table-search-result').html('Showing all results for"' + $(this).val() + '"');
            $('.search-clear').css('display', 'block');
            //Showing all results for “ch”
        } else {
            $('.table-search-result').html('');
            $('.search-clear').css('display', 'none');
        }
    });
    $('.clear-desktop').click(function() {
        $("#searchInput").val('');
        $('.table-search-result').html('');
        $(this).css('display', 'none');
        $('#vestaTable').DataTable().search($(this).val()).draw();
    });

    $('.data_List').click(function() {
        // $(this).parents('.data_List').toggleClass('active')
        $(this).toggleClass('active');
    });
    $('.clear-users').click(function() {
        $("#searchData").val('');
        $(this).css('display', 'none');
    });
    $('.clear-users').click(function() {
        $("#searchUsers").val('');
        $('.table-search-result').html('');
        $(this).css('display', 'none');
        $('#userTable').DataTable().search($(this).val()).draw();
    });

    $('.clear-mobile').click(function() {
        $("#searchInputM").val('');
        $(this).css('display', 'none');
    });

});