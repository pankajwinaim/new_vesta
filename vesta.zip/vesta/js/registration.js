
$(function() {
    $(".iti__country-list").addClass('scroller_bar');
    $(".iti__country-name").hide()
    $(".iti__country ").click(function(){
        var country_code = $(this).children(".iti__dial-code").text();
        $("#phone").val(country_code);
        $(".ph_no").focus();
      
    })
    $('.reg_cont').click(function() {
        var com_name    = $(".company-name").val();
        var first_name  = $(".first-name").val();
        var last_name   = $(".last-name").val();
        var email       = $(".email").val();
        var ph_no       = $(".ph_no").val();
        
        if(email == '') {
            $(".is_null").show();
            $(".is_check").hide();
            $('.email').parents('.form-group').addClass('error_state')
        }else{
            $('.email').parents('.form-group').removeClass('error_state')
            var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;;
            if(!mailFormat.test(email)) {
                $(".is_null").hide();
                $(".is_check").show();
                $('.email').parents('.form-group').addClass('error_state')
            }else{
                $('.email').parents('.form-group').removeClass('error_state')
                $(".is_null").hide();
                $(".is_check").hide();
            }
        }

        if(com_name!='' && first_name!="" && last_name!="" && email!="" && ph_no!=""){

        }else {
            if(com_name == '') {
                $('.company-name').parents('.form-group').addClass('error_state')
            }else{
                $('.company-name').parents('.form-group').removeClass('error_state')
            }
    
            if(first_name == '') {
                $('.first-name').parents('.col-6').addClass('error_state')
            }else{
                $('.first-name').parents('.col-6').removeClass('error_state')
            }
    
            if(last_name == '') {
                $('.last-name').parents('.col-6').addClass('error_state')
            }else{
                $('.last-name').parents('.col-6').removeClass('error_state')
            }

            if(ph_no == '') {
                $('.ph_no').parents('.form-group').addClass('error_state')
            }else{
                $('.ph_no').parents('.form-group').removeClass('error_state')
            }
        }
    });


});
