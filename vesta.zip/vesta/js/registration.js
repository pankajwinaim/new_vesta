
$(function() {
    $(".iti__country-list").addClass('scroller_bar');
    $(".iti__country-name").hide()
    $(".iti__country ").click(function(){
        var country_code = $(this).children(".iti__dial-code").text();
        $("#phone").val(country_code);
        $(".ph_no").focus();
    })
    $(".company-name").keyup(function(){
        if($(this).val() != ""){
            $('.company-name').parents('.form-group').removeClass('error_state')
        }else{
            $('.company-name').parents('.form-group').addClass('error_state')
        }
    })

    $(".first-name").keyup(function(){
        if($(this).val() != ""){
            $('.first-name').parents('.col-6').removeClass('error_state')
        }else{
            $('.first-name').parents('.col-6').addClass('error_state')
        }
    })
    $(".last-name").keyup(function(){
        if($(this).val() != ""){
            $('.last-name').parents('.col-6').removeClass('error_state')
        }else{
            $('.last-name').parents('.col-6').addClass('error_state')
        }
    })

    $(".ph_no").keyup(function(){
        if($(this).val() != ""){
            $('.ph_no').parents('.form-group').removeClass('error_state')
        }else{
            $('.ph_no').parents('.form-group').addClass('error_state')
        }
    })

    $(".email").keyup(function(){
        var email      = $(this).val();
        var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(email == '') {
            $(".is_null").show();
            $(".is_check").hide();
            $('.email').parents('.form-group').addClass('error_state')
        }else{
            $('.email').parents('.form-group').removeClass('error_state')
            var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;;
            if(!mailFormat.test(email)) {
                $(".is_null").hide();
                $(".is_check").show();
                $('.email').parents('.form-group').addClass('error_state')
            }else{
                $('.email').parents('.form-group').removeClass('error_state')
                $(".is_null").hide();
                $(".is_check").hide();
            }
        }
    })

    $(".email").focusout(function() {
        var email      = $(this).val();
        var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(email == '') {
            $(".is_null").show();
            $(".is_check").hide();
            $('.email').parents('.form-group').addClass('error_state')
        }else{
            $('.email').parents('.form-group').removeClass('error_state')
            var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;;
            if(!mailFormat.test(email)) {
                $(".is_null").hide();
                $(".is_check").show();
                $('.email').parents('.form-group').addClass('error_state')
            }else{
                $('.email').parents('.form-group').removeClass('error_state')
                $(".is_null").hide();
                $(".is_check").hide();
                $url = "https://myjson.dit.upm.es/api/bins/2pu9";
                $data = {
                    'email':email
                }
                $.ajax({
                    url: $url,
                    data: $data,
                    success: function(result){
                        console.log("data");
                    }
                });
            }
        }
    })

    $('.reg_cont').click(function(event ) {
        var com_name    = $(".company-name").val();
        var first_name  = $(".first-name").val();
        var last_name   = $(".last-name").val();
        var email       = $(".email").val();
        var ph_no       = $(".ph_no").val();
        var ph_code     = $(".ph_code").val();
        var job_func    = $(".job_func").val();
        var product_id  = $(".product_id").val();
        var county      = $(".niceCountryInputMenuDefaultText").children("a").children("a").children("span").text();
        if(county == ''){county = "United States"; }
        var currency = $(".btn-select").val();
        if(currency == '' || currency == 'en' ){currency = "USD"; }
        var email_check = "0";
        if(email == '') {
            $(".is_null").show();
            $(".is_check").hide();
            $('.email').parents('.form-group').addClass('error_state')
        }else{
            $('.email').parents('.form-group').removeClass('error_state')
            var mailFormat = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;;
            if(!mailFormat.test(email)) {
                $(".is_null").hide();
                $(".is_check").show();
                $('.email').parents('.form-group').addClass('error_state')
            }else{
                $('.email').parents('.form-group').removeClass('error_state')
                $(".is_null").hide();
                $(".is_check").hide();
                email_check = "1";
            }
        }

        if(com_name!='' && first_name!="" && last_name!="" && email_check!="0" && ph_no!=""){
            if(ph_code == ""){
                ph_code = "+91";
            }

            $data = {
                "company_name": com_name,
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "ph_code": ph_code,
                "ph_no": ph_no,
                "job_func": job_func,
                "country": county,
                "currency": currency,
                "product_id": product_id,

            };
            console.log($data)
            $url = "https://myjson.dit.upm.es/api/bins/2pu9";
            $.ajax({
                url: $url,
                data: $data,
                success: function(result){
                    console.log("data");
                }
            });
        }else {
            if(com_name == '') {
                $('.company-name').parents('.form-group').addClass('error_state')
            }else{
                $('.company-name').parents('.form-group').removeClass('error_state')
            }
    
            if(first_name == '') {
                $('.first-name').parents('.col-6').addClass('error_state')
            }else{
                $('.first-name').parents('.col-6').removeClass('error_state')
            }
    
            if(last_name == '') {
                $('.last-name').parents('.col-6').addClass('error_state')
            }else{
                $('.last-name').parents('.col-6').removeClass('error_state')
            }

            if(ph_no == '') {
                $('.ph_no').parents('.form-group').addClass('error_state')
            }else{
                $('.ph_no').parents('.form-group').removeClass('error_state')
            }
        }
    });


});
