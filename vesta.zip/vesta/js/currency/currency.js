function runTime() {

var langArray = [];

$('.cc_btn option').each(function(){
    var img = $(this).attr("data-thumbnail");
    var text = this.innerText;
    var value = $(this).val();
    var item = '<li><img class="ccImg" src="'+ img +'" alt="" value="'+value+'"/><span class="ccDesp">'+ text +'</span></li>';
    langArray.push(item);
})
if(langArray.length>0)
$('#cc_lists').html(langArray);

//Set the button value to the first el of the array

$('.btn-select').html(langArray[0]);
$('.btn-select').attr('value', 'en');

//change button stuff on click
$('#cc_lists li').click(function(){
    var img = $(this).find('img').attr("src");
    var value = $(this).find('img').attr('value');
    var text = this.innerText;
    var item = '<li><img class="ccImg" src="'+ img +'" alt="" /><span class="ccDesp">'+ text +'</span></li>';
    $('.btn-select').html(item);
    $('.btn-select').attr('value', value);
    $(".cc_container").toggle();
    $("#currencySearch").toggle();
});

$(".btn-select").click(function(){
        $(".cc_container").toggle();
        $("#currencySearch").toggle();
    });
var sessionLang = localStorage.getItem('lang');
if (sessionLang){
  var langIndex = langArray.indexOf(sessionLang);
  $('.btn-select').html(langArray[langIndex]);
  $('.btn-select').attr('value', sessionLang);
} else {
   var langIndex = langArray.indexOf('ch');
    $('.btn-select').html(langArray[langIndex]);
}
}